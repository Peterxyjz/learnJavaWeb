package pe.account;

public class AccountDTO {
    //your code here
    
}
