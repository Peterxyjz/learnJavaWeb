package pe.employee;

public class EmployeeDAO {
    //your code here
    
}
